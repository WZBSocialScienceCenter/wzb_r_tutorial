# R Tutorial at the WZB
# Accompanying script for "Tasks for 12 – Introduction to Machine Learning with R I"
# January 31, 2019
#

library(caret)
library(MASS)   # for Boston data and lm.ridge
library(dplyr)
library(tidyr)
library(e1071)  # for skewness function
library(corrplot)

set.seed(1453)  # for reproducibility

#
# create training and test data sets
#

in_train_indices <- createDataPartition(Boston$medv, p = 0.75, list = FALSE)

boston_train <- Boston[in_train_indices,]
boston_test <- Boston[-in_train_indices,]

#
# data preprocessing
#

# calculate skewness statistic per column
apply(boston_train, 2, skewness)

# apply Box-Cox transformation to "dis" (results in log transform)
qplot(boston_train$dis, bins = 20)
(dis_trans <- BoxCoxTrans(boston_train$dis))
boston_train$dis_trans <- predict(dis_trans, boston_train$dis)
qplot(boston_train$dis_trans, bins = 20)

boston_train <- select(boston_train, -dis)

# remove near-zero variance predictors
nearZeroVar(boston_train, names = TRUE)
boston_train <- boston_train[, -nearZeroVar(boston_train)]

# investigate pairwise correlations
correl <- cor(boston_train)
correl
corrplot(correl, order = 'hclust')

# remove pairwise correlated predictors above correl. value 0.9
varnames <- names(boston_train)
corr_var_indices <- findCorrelation(correl, cutoff = 0.9)
varnames[corr_var_indices]
boston_train <- boston_train[, -corr_var_indices]


#
# model tuning
#

# create hyperparameter value candidates
ridge_hyperparam_sets <- data.frame(.lambda = seq(0, 0.1, by = 0.01))
ridge_hyperparam_sets

# set resampling strategy
train_ctrl <- trainControl(method = 'repeatedcv', number = 10, repeats = 5)

# start the tuning process
boston_train_X <- select(boston_train, -medv)
boston_train_Y <- boston_train$medv

tuning_ridge <- train(boston_train_X, boston_train_Y, method = 'ridge',
                      tuneGrid = ridge_hyperparam_sets,
                      trControl = train_ctrl,
                      preProcess = c('center', 'scale'))   # centering and scaling for ridge recommended

#
# investigate tuning results
#

tuning_ridge

# gives best model for lambda = 0.02 with
# RMSE = 4.768482
# R² = 0.7382246
# MAE = 3.442588

# plot performance measurements against lambda values
results_for_plot <- select(tuning_ridge$results, -ends_with('SD')) %>%
  gather(RMSE:MAE, key = 'metric', value = 'value')

ggplot(results_for_plot, aes(x = lambda, y = value)) +
  geom_point() + geom_line() +
  facet_grid(metric ~ ., scales = 'free_y')

# make observed vs. predicted plot for best ridge model
boston_train_X_scaled <- predict(tuning_ridge$preProcess, newdata = boston_train_X)
ridge_pred <- predict(tuning_ridge$finalModel, newx = boston_train_X_scaled,
                      s = 1, type = 'fit', mode = 'fraction')$fit
qplot(boston_train_Y, ridge_pred, geom = 'point') +
  geom_abline(intercept = 0, slope = 1) +
  coord_fixed() + xlab('observed') + ylab('predicted') +
  theme_minimal()

# extract coefficients
predict(tuning_ridge$finalModel, s = 1, type = 'coefficients', mode = 'fraction')$coefficients

# --------------------------------------------------------------------------------------------

# complete script here (see exercise description)
