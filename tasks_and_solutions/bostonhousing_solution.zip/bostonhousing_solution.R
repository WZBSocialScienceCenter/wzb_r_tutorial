# R Tutorial at the WZB
# Accompanying script for "Tasks for 12 – Introduction to Machine Learning with R I"
# January 31, 2019
#
# - Solution -
#

library(caret)
library(MASS)   # for Boston data and lm.ridge
library(dplyr)
library(tidyr)
library(e1071)  # for skewness function
library(corrplot)

set.seed(1453)  # for reproducibility

#
# create training and test data sets
#

in_train_indices <- createDataPartition(Boston$medv, p = 0.75, list = FALSE)

boston_train <- Boston[in_train_indices,]
boston_test <- Boston[-in_train_indices,]

#
# data preprocessing
#

# calculate skewness statistic per column
apply(boston_train, 2, skewness)

# apply Box-Cox transformation to "dis" (results in log transform)
qplot(boston_train$dis, bins = 20)
(dis_trans <- BoxCoxTrans(boston_train$dis))
boston_train$dis_trans <- predict(dis_trans, boston_train$dis)
qplot(boston_train$dis_trans, bins = 20)

boston_train <- select(boston_train, -dis)

# remove near-zero variance predictors
nearZeroVar(boston_train, names = TRUE)
boston_train <- boston_train[, -nearZeroVar(boston_train)]

# investigate pairwise correlations
correl <- cor(boston_train)
correl
corrplot(correl, order = 'hclust')

# remove pairwise correlated predictors above correl. value 0.9
varnames <- names(boston_train)
corr_var_indices <- findCorrelation(correl, cutoff = 0.9)
varnames[corr_var_indices]
boston_train <- boston_train[, -corr_var_indices]


#
# model tuning
#

# create hyperparameter value candidates
ridge_hyperparam_sets <- data.frame(.lambda = seq(0, 0.1, by = 0.01))
ridge_hyperparam_sets

# set resampling strategy
train_ctrl <- trainControl(method = 'repeatedcv', number = 10, repeats = 5)

# start the tuning process
boston_train_X <- select(boston_train, -medv)
boston_train_Y <- boston_train$medv

tuning_ridge <- train(boston_train_X, boston_train_Y, method = 'ridge',
                      tuneGrid = ridge_hyperparam_sets,
                      trControl = train_ctrl,
                      preProcess = c('center', 'scale'))   # centering and scaling for ridge recommended

#
# investigate tuning results
#

tuning_ridge

# gives best model for lambda = 0.02 with
# RMSE = 4.768482
# R² = 0.7382246
# MAE = 3.442588

# plot performance measurements against lambda values
results_for_plot <- select(tuning_ridge$results, -ends_with('SD')) %>%
  gather(RMSE:MAE, key = 'metric', value = 'value')

ggplot(results_for_plot, aes(x = lambda, y = value)) +
  geom_point() + geom_line() +
  facet_grid(metric ~ ., scales = 'free_y')

# make observed vs. predicted plot for best ridge model
boston_train_X_scaled <- predict(tuning_ridge$preProcess, newdata = boston_train_X)
ridge_pred <- predict(tuning_ridge$finalModel, newx = boston_train_X_scaled,
                      s = 1, type = 'fit', mode = 'fraction')$fit
qplot(boston_train_Y, ridge_pred, geom = 'point') +
  geom_abline(intercept = 0, slope = 1) +
  coord_fixed() + xlab('observed') + ylab('predicted') +
  theme_minimal()

# extract coefficients
predict(tuning_ridge$finalModel, s = 1, type = 'coefficients', mode = 'fraction')$coefficients

# --------------------------------------------------------------------------------------------

# complete script here (see exercise description)

#
# 2. Tuning a Random Forest model
#

# make a range of mtry parameter values from 2 to 9
rf_hyperparam_sets <- data.frame(.mtry = seq(2, 9))

# this may take a while...
tuning_rf <- train(boston_train_X, boston_train_Y, method = 'rf',
                   tuneGrid = rf_hyperparam_sets,
                   trControl = train_ctrl)

#
# investigate tuning results
#

tuning_rf

# gives best model for mtry = 4 with
# RMSE = 3.412906
# R² = 0.8682942
# MAE = 2.329382
# so a bit better than ridge regression

# plot performance measurements against mtry values

results_for_plot <- select(tuning_rf$results, -ends_with('SD')) %>%
  gather(RMSE:MAE, key = 'metric', value = 'value')

ggplot(results_for_plot, aes(x = mtry, y = value)) +
  geom_point() + geom_line() +
  facet_grid(metric ~ ., scales = 'free_y')


# make observed vs. predicted plot for best RF model
rf_pred <- predict(tuning_rf$finalModel, boston_train_X)
qplot(boston_train_Y, rf_pred, geom = 'point') +
  geom_abline(intercept = 0, slope = 1) +
  coord_fixed() + xlab('observed') + ylab('predicted') +
  theme_minimal()

# variable importance
randomForest::varImpPlot(tuning_rf$finalModel)

#
# 3. Final validation using held-out test data
#

# apply the same data pre-processing to the test data as to the training data
boston_test$dis_trans <- predict(dis_trans, boston_test$dis)
boston_test <- boston_test[,names(boston_train)]   # use the same subset of predictors as training data

boston_test_X <- select(boston_test, -medv)
boston_test_Y <- boston_test$medv
preproc_centerscale_test <- preProcess(boston_test_X, method = c('center', 'scale'))     # for ridge, also center and scale
boston_test_X_centerscaled <- predict(preproc_centerscale_test, newdata = boston_test_X)

# predict outcomes of test data for ridge regression
ridge_pred <- predict(tuning_ridge$finalModel, newx = boston_test_X_centerscaled,
                      s = 1, type = 'fit', mode = 'fraction')$fit

# calculate performance measurments for ridge regression on test data
RMSE(ridge_pred, boston_test_Y)
R2(ridge_pred, boston_test_Y)
MAE(ridge_pred, boston_test_Y)

# make a observed vs. predicted plot for ridge regression
qplot(boston_test_Y, ridge_pred, geom = 'point') + geom_abline(intercept = 0, slope = 1) +
  coord_fixed() + xlab('observed') + ylab('predicted') + xlim(0, 50) + ylim(0, 50) +
  theme_minimal()

# predict outcomes of test data for RF
rf_pred <- predict(tuning_rf$finalModel, boston_test_X)

# calculate performance measurments for RF on test data
RMSE(rf_pred, boston_test_Y)
R2(rf_pred, boston_test_Y)
MAE(rf_pred, boston_test_Y)

# make a observed vs. predicted plot for RF
qplot(boston_test_Y, rf_pred, geom = 'point') + geom_abline(intercept = 0, slope = 1) +
  coord_fixed() + xlab('observed') + ylab('predicted')+ xlim(0, 50) + ylim(0, 50) +
  theme_minimal()

# We conclude that for this data set, our RF model outperforms the ridge regression model
# However, we could still opt for the ridge regression model, because it is easier to interprete
# and less computationally intensive.

