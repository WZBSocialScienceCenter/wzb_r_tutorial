# Plotting functions for heatmaps from DTM / distances (using ggplot2)
# Nov. 2018
# Markus Konrad <markus.konrad@wzb.eu>
#

library(ggplot2)
library(tidyr)

plot_dtm_heatmap <- function(dtm, xlabel = NULL, ylabel = 'document', value_labels_size = 4, round_values_digits = NULL) {
  orig_rownames <- rownames(dtm)
  if (is.null(orig_rownames)) {
    row_names <- as.character(1:nrow(dtm))
  } else {
    row_names <- orig_rownames
  }
  
  df <- as.data.frame(dtm)
  df$row_names <- row_names
  df <- df %>% gather(key = 'term', value = 'n', -row_names)
  
  if (!('term') %in% colnames(df) && 'V1' %in% colnames(df)) {
    df$term <- 1
    df$n <- df$V1
  }
  
  if (!is.null(round_values_digits)) {
    df$values_label <- round(df$n, round_values_digits)
  } else {
    df$values_label <- df$n
  }
  
  ggplot(df, aes(x = term, y = row_names, fill = n)) +
    geom_tile(color = 'white', size = 1.5) +
    geom_text(aes(x = term, y = row_names, label = values_label), size = value_labels_size) +
    xlab(xlabel) +
    ylab(ylabel) +
    scale_fill_distiller(guide = FALSE) +
    scale_y_discrete(limits = rev(row_names)) +
    coord_fixed() +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
}


plot_dist_heatmap <- function(distmat, value_labels_size = 3, round_values_digits = 2) {
  if (class(distmat) == 'dist') {
    distmat <- as.matrix(distmat)
  }
  
  df <- as.data.frame(distmat)
  row_names <- rownames(distmat)
  df$row_names <- row_names
  df <- df %>% gather(key = 'doc', value = 'distval', -row_names) %>%
    mutate(distval_lbl = as.character(round(distval, round_values_digits)))
  
  ggplot(df, aes(x = doc, y = row_names, fill = distval)) +
    geom_tile(color = 'white', size = 1.5) +
    geom_text(aes(x = doc, y = row_names, label = distval_lbl), size = value_labels_size) +
    scale_fill_distiller(guide = FALSE) +
    xlab(NULL) + ylab(NULL) +
    coord_fixed() +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
}
