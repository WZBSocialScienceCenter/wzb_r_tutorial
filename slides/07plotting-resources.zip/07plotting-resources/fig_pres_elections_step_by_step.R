library(tidyverse)

library(pscl)   # this is where the data set "presidentialElections" comes from

set.seed(123)

sampled_states <- presidentialElections %>%
  distinct(state, south) %>%
  group_by(south) %>%    # group by south / not south
  sample_n(2) %>%        # take 2 from each group
  ungroup() %>%
  select(state) %>%
  unlist(use.names = FALSE)  # convert to simple vector

sampled_pres <- filter(presidentialElections, state %in% sampled_states)
sampled_pres

# goal: plot `year` on X, voting share for democrats (`demVote`) on Y
#       make color dependent on `south`
#       make small multiples per `state` ("facetting")











ggplot(sampled_pres)

ggplot(sampled_pres, aes(x = year, y = demVote, color = south))

ggplot(sampled_pres, aes(x = year, y = demVote, color = south)) + geom_line()

ggplot(sampled_pres, aes(x = year, y = demVote, color = south)) + geom_line() + facet_wrap(~ state, nrow = 2)

# customize more ...

# alternative:

ggplot(sampled_pres, aes(x = year, y = demVote, color = state, linetype = south)) + geom_line()

