library(MASS)

data(cats)

female_cats <- cats[cats$Sex == 'F',]
mean_bwt_fem <- mean(female_cats$Bwt)

